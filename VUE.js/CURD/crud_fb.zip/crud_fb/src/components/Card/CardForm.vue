<template>
  <div>
    <!-- Add Information Button and Form -->
    <div class="mb-3 p-4">
      <button type="button" class="btn btn-success" @click="toggleForm">Add Information</button>
      <form
        v-if="showForm"
        @submit.prevent="handleSubmit"
        style="width: 400px;"
        class="text-start p-3 mb-2 bg-success text-white rounded"
      >
        <div class="mb-4">
          <label for="title">Title:</label>
          <input type="text" id="title" class="form-control" v-model="formData.title" required />
        </div>
        <div class="mb-4">
          <label for="commend">Commend:</label>
          <input type="text" id="commend" class="form-control" v-model="formData.commend" required />
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
      </form>
    </div>

    <!-- Search Form -->
    <div class="mb-3 ms-5 p-4 d-flex d-grid gap-2 " style="width: 400px;">
      <input type="text" class="form-control" placeholder="Search by title" v-model="searchQuery" />
      <img src="https://cdn-icons-png.flaticon.com/512/8122/8122729.png" alt="" width="50px"  class="bg-primary btn ">
    </div>

    <!-- Table Display -->
    <div class="p-4">
      <table class="table table-bordered table-hover">
        <thead>
          <tr>
            <th scope="col">Id</th>
            <th scope="col">Title</th>
            <th scope="col">Commend</th>
            <th scope="col">Action</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(item, index) in filteredTable" :key="index">
            <th scope="row">{{ index + 1 }}</th>
            <td>{{ item.title }}</td>
            <td>{{ item.commend }}</td>
            <td class="gap-3" style="width: 30%;">
              <button class="btn btn-primary btn-sm" @click="viewItem(index)">View</button>
              <button class="btn btn-warning btn-sm ms-3" @click="editItem(index)">Edit</button>
              <button class="btn btn-danger btn-sm ms-3" @click="deleteItem(index)">Delete</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>
  
  <script>
export default {
  name: "CardFormVue",
  data() {
    return {
      showForm: false,
      searchQuery: "",
      table: [
        { title: "Mark", commend: "Otto", action: "" },
        { title: "Jacob", commend: "Thornton", action: "" }
      ],
      formData: {
        title: "",
        commend: ""
      },
      editIndex: null
    };
  },
  computed: {
    filteredTable() {
      return this.table.filter(item =>
        item.title.toLowerCase().includes(this.searchQuery.toLowerCase())
      );
    }
  },
  methods: {
    toggleForm() {
      this.showForm = !this.showForm;
    },
    handleSubmit() {
      if (this.editIndex === null) {
        // Adding a new item
        this.table.push({
          title: this.formData.title,
          commend: this.formData.commend,
          action: ""
        });
      } else {
        // Updating an existing item
        this.table[this.editIndex].title = this.formData.title;
        this.table[this.editIndex].commend = this.formData.commend;
        this.editIndex = null;
      }
      this.formData.title = "";
      this.formData.commend = "";
      this.showForm = false;
    },
    viewItem(index) {
      alert(
        `Viewing item:\nTitle: ${this.table[index].title}\nCommend: ${this.table[index].commend}`
      );
    },
    editItem(index) {
      this.formData.title = this.table[index].title;
      this.formData.commend = this.table[index].commend;
      this.editIndex = index;
      this.showForm = true;
    },
    deleteItem(index) {
      this.table.splice(index, 1);
    }
  }
};
</script>
  
  <style scoped>
</style>
  