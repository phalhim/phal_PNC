<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Post extends Model

{
    public static function list()
    {
        return self::all();
    }
    protected $fillable = ['name', 'category', 'description'];

}
